package shared.util;

import javax.sound.sampled.Port;

public class Connection {
    public static final int PORT = 1913;
    public static final String HOST = "localhost";
}
