package client;

import javafx.application.Application;

public class RunApp {
    public static void main(String[] args) {
        Application.launch(ChatApp.class);
    }
}
